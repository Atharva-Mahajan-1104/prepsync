import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import express from 'express';
import axios from 'axios';
import natural from 'natural';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import helmet from 'helmet';

// Load production environment variables
dotenv.config({ path: '.env.production' });

const app = express();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Security middleware
app.use(helmet());

// Rate limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100 // limit each IP to 100 requests per windowMs
});
app.use(limiter);

// CORS configuration
const corsOptions = {
    origin: process.env.CORS_ORIGIN || 'https://your-frontend-domain.com',
    optionsSuccessStatus: 200
};
app.use(cors(corsOptions));

app.use(express.json());

// Serve static files from the React app
app.use(express.static(path.join(__dirname, '..', 'dist')));

// Import your existing routes and logic here
import { questions, evaluateAnswer, generateQuestions } from './index.js';

// Apply your existing routes
app.get('/questions/:role', (req, res) => {
    try {
        const role = req.params.role;
        if (!role) return res.status(400).json({ error: "Role parameter is required" });

        const roleQuestions = questions[role];
        if (!roleQuestions) return res.status(404).json({ error: `No questions found for role: ${role}` });

        const expLevel = req.query.experienceLevel;
        if (expLevel) {
            const allowed = allowedDifficultiesForLevel(expLevel);
            if (Array.isArray(allowed)) {
                const filtered = roleQuestions.filter((q) => {
                    const diff = (q.difficulty || 'Medium').toString().toLowerCase();
                    return allowed.includes(diff);
                });
                return res.json(filtered.length ? filtered : roleQuestions);
            }
        }

        res.json(roleQuestions);
    } catch (error) {
        console.error('Error fetching questions:', error);
        res.status(500).json({ error: "Failed to fetch questions" });
    }
});

app.post("/evaluate", (req, res) => {
    try {
        const { answer, question, role, company, experienceLevel } = req.body;
        if (!answer || !question || !question.requiredKeywords)
            return res.status(400).json({ error: "Missing required data" });

        const result = evaluateAnswer(answer, question, { role, company, experienceLevel });
        res.json(result);
    } catch (error) {
        console.error("Evaluation error:", error);
        res.status(500).json({ error: "Failed to analyze answer" });
    }
});

app.post("/generate-question", async (req, res) => {
    try {
        const { company, role, experienceLevel } = req.body;
        if (!company || !role || !experienceLevel) {
            return res.status(400).json({
                error: "Missing parameters. Please provide company, role, and experienceLevel.",
            });
        }
        const questions = await generateQuestions({ company, role, experienceLevel });
        return res.json(questions);
    } catch (err) {
        console.error("Error generating questions:", err);
        return res.status(500).json({ error: "Failed to generate questions dynamically" });
    }
});

// Handle React routing, return all requests to React app
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'dist', 'index.html'));
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
    console.log(`🚀 Production server running on port ${PORT}`);
});