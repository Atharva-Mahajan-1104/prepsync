import dotenv from 'dotenv';
import express from 'express';
import axios from 'axios';
import natural from 'natural';
import cors from 'cors';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// -------------------- STATIC QUESTION BANK --------------------
const questions = {
  "Core Software Engineer": [
    // Intern level
    {
      question: "What is the difference between stack and heap memory?",
      difficulty: "Easy",
      requiredKeywords: ["Stack", "Heap", "Static", "Dynamic", "Memory"]
    },
    {
      question: "Explain what a loop is and its basic types.",
      difficulty: "Easy",
      requiredKeywords: ["For", "While", "Iteration", "Condition", "Break"]
    },
    // Junior level
    {
      question: "Describe common data structures and their use cases.",
      difficulty: "Easy",
      requiredKeywords: ["Array", "LinkedList", "Queue", "Stack", "Tree"]
    },
    {
      question: "What is Object-Oriented Programming and its main principles?",
      difficulty: "Medium",
      requiredKeywords: ["Inheritance", "Encapsulation", "Polymorphism", "Classes", "Objects"]
    },
    // Mid level
    {
      question: "Explain the concept of memory management in programming languages.",
      difficulty: "Medium",
      requiredKeywords: ["Stack", "Heap", "Garbage Collection", "Memory Leak", "Allocation"]
    },
    {
      question: "What are design patterns and why are they important?",
      difficulty: "Medium",
      requiredKeywords: ["Singleton", "Factory", "Observer", "Reusability", "Architecture"]
    },
    // Senior level
    {
      question: "How would you design a distributed caching system?",
      difficulty: "Hard",
      requiredKeywords: ["Consistency", "Partitioning", "Replication", "Latency", "Scalability"]
    },
    {
      question: "Explain advanced concurrency patterns and their trade-offs.",
      difficulty: "Hard",
      requiredKeywords: ["Mutex", "Deadlock", "Threading", "Synchronization", "Race Condition"]
    }
  ],
  "Frontend Developer": [
    // Intern level
    {
      question: "What is HTML semantic markup and why is it important?",
      difficulty: "Easy",
      requiredKeywords: ["Accessibility", "SEO", "Header", "Nav", "Semantic"]
    },
    {
      question: "Explain CSS box model and basic layout concepts.",
      difficulty: "Easy",
      requiredKeywords: ["Margin", "Padding", "Border", "Content", "Box-sizing"]
    },
    // Junior level
    {
      question: "Explain the Virtual DOM and its benefits.",
      difficulty: "Easy",
      requiredKeywords: ["Performance", "Reconciliation", "React", "Rendering", "DOM"]
    },
    {
      question: "What are CSS preprocessors and their advantages?",
      difficulty: "Medium",
      requiredKeywords: ["SASS", "Variables", "Nesting", "Mixins", "Compilation"]
    },
    // Mid level
    {
      question: "Describe the concept of state management in frontend applications.",
      difficulty: "Medium",
      requiredKeywords: ["Redux", "Store", "Actions", "State", "Immutability"]
    },
    {
      question: "Explain modern JavaScript module systems and bundling.",
      difficulty: "Medium",
      requiredKeywords: ["ESModules", "Webpack", "Import", "Export", "Tree-shaking"]
    },
    // Senior level
    {
      question: "Design a scalable frontend architecture for a large enterprise app.",
      difficulty: "Hard",
      requiredKeywords: ["Microfrontends", "Performance", "Caching", "Authentication", "Modular"]
    },
    {
      question: "Implement advanced React patterns and optimizations.",
      difficulty: "Hard",
      requiredKeywords: ["HOC", "Hooks", "Memoization", "Suspense", "Code-splitting"]
    }
  ],
  "Backend Developer": [
    // Intern level
    {
      question: "What is CRUD and how is it used in APIs?",
      difficulty: "Easy",
      requiredKeywords: ["Create", "Read", "Update", "Delete", "API"]
    },
    {
      question: "Explain basic HTTP methods and status codes.",
      difficulty: "Easy",
      requiredKeywords: ["GET", "POST", "PUT", "DELETE", "Status"]
    },
    // Junior level
    {
      question: "Describe RESTful API design principles.",
      difficulty: "Easy",
      requiredKeywords: ["Stateless", "Resources", "HTTP", "Endpoints", "Methods"]
    },
    {
      question: "What are the basics of database indexing?",
      difficulty: "Medium",
      requiredKeywords: ["Index", "Query", "Performance", "Primary Key", "Search"]
    },
    // Mid level
    {
      question: "Explain the differences between SQL and NoSQL databases.",
      difficulty: "Medium",
      requiredKeywords: ["Scalability", "Schema", "ACID", "Document", "Relational"]
    },
    {
      question: "Describe microservices architecture patterns.",
      difficulty: "Medium",
      requiredKeywords: ["Services", "Communication", "Gateway", "Docker", "Deployment"]
    },
    // Senior level
    {
      question: "Design a high-throughput message processing system.",
      difficulty: "Hard",
      requiredKeywords: ["Kafka", "Queue", "Scaling", "Partitioning", "Consistency"]
    },
    {
      question: "Implement advanced database sharding strategies.",
      difficulty: "Hard",
      requiredKeywords: ["Sharding", "Replication", "Consistency", "Distribution", "Failover"]
    }
  ],
  "AI/ML Engineer": [
    // Intern level
    {
      question: "What is the difference between AI, ML, and Deep Learning?",
      difficulty: "Easy",
      requiredKeywords: ["Artificial", "Machine", "Neural", "Data", "Learning"]
    },
    {
      question: "Explain basic data preprocessing steps.",
      difficulty: "Easy",
      requiredKeywords: ["Cleaning", "Normalization", "Features", "Missing", "Scaling"]
    },
    // Junior level
    {
      question: "Explain the difference between supervised and unsupervised learning.",
      difficulty: "Easy",
      requiredKeywords: ["Labels", "Clustering", "Classification", "Training", "Dataset"]
    },
    {
      question: "What are common evaluation metrics in ML?",
      difficulty: "Medium",
      requiredKeywords: ["Accuracy", "Precision", "Recall", "F1-Score", "ROC"]
    },
    // Mid level
    {
      question: "Describe how neural networks work.",
      difficulty: "Medium",
      requiredKeywords: ["Neurons", "Layers", "Weights", "Backpropagation", "Activation"]
    },
    {
      question: "Explain different types of CNN architectures.",
      difficulty: "Medium",
      requiredKeywords: ["Convolution", "Pooling", "ResNet", "VGG", "Features"]
    },
    // Senior level
    {
      question: "Design an end-to-end ML pipeline for production.",
      difficulty: "Hard",
      requiredKeywords: ["Pipeline", "Monitoring", "Deployment", "Version", "Scale"]
    },
    {
      question: "Implement advanced NLP transformer architectures.",
      difficulty: "Hard",
      requiredKeywords: ["Attention", "BERT", "Embedding", "Transfer", "Fine-tuning"]
    }
  ],
  "Cloud Engineer": [
    // Intern level
    {
      question: "What are the basic cloud service models?",
      difficulty: "Easy",
      requiredKeywords: ["IaaS", "PaaS", "SaaS", "Cloud", "Service"]
    },
    {
      question: "Explain basic cloud storage types.",
      difficulty: "Easy",
      requiredKeywords: ["Block", "Object", "File", "Storage", "Persistence"]
    },
    // Junior level
    {
      question: "Explain the concept of containerization and its benefits.",
      difficulty: "Easy",
      requiredKeywords: ["Docker", "Isolation", "Microservices", "Portability", "Orchestration"]
    },
    {
      question: "What is Infrastructure as Code?",
      difficulty: "Medium",
      requiredKeywords: ["Terraform", "Automation", "Configuration", "Version", "Deploy"]
    },
    // Mid level
    {
      question: "Describe the principles of cloud-native architecture.",
      difficulty: "Medium",
      requiredKeywords: ["Scalability", "Containers", "Microservices", "DevOps", "Automation"]
    },
    {
      question: "Explain cloud security best practices.",
      difficulty: "Medium",
      requiredKeywords: ["IAM", "Encryption", "Security Groups", "Compliance", "Monitoring"]
    },
    // Senior level
    {
      question: "Design a multi-region disaster recovery solution.",
      difficulty: "Hard",
      requiredKeywords: ["Failover", "Replication", "RTO", "RPO", "Backup"]
    },
    {
      question: "Implement advanced Kubernetes operators and CRDs.",
      difficulty: "Hard",
      requiredKeywords: ["Kubernetes", "Operator", "Custom", "Controller", "Resources"]
    }
  ]
};

function allowedDifficultiesForLevel(level) {
  const l = (level || '').toString().toLowerCase();
  switch (l) {
    case 'intern':
      return ['easy'];
    case 'junior':
      return ['easy', 'medium'];
    case 'mid':
      return ['medium'];
    case 'senior':
      return ['medium', 'hard'];
    default:
      return null; // no filtering
  }
}


// -------------------- EVALUATION LOGIC --------------------
function evaluateAnswer(answer, question, context = {}) {
  try {
    const { role = "General", company = "Generic", experienceLevel = "Mid" } = context;

    const tokenizer = new natural.WordTokenizer();
    const stemmer = natural.PorterStemmer;
    const TfIdf = natural.TfIdf;
    const tfidf = new TfIdf();

    const answerTokens = tokenizer.tokenize(answer.toLowerCase());
    const requiredKeywords = question.requiredKeywords.map(k => k.toLowerCase());

    // 🧠 1. Basic text stats
    const wordCount = answerTokens.length;
    const uniqueWords = new Set(answerTokens).size;
    const sentences = answer.split(/[.!?]+/).filter(Boolean);
    const sentenceCount = sentences.length;
    const averageWordLength = wordCount > 0 ? answer.length / wordCount : 0;

    // 🧩 2. Keyword matching using stemming + fuzzy distance
    const matchedKeywords = requiredKeywords.filter(keyword => {
      const keywordStem = stemmer.stem(keyword);
      return answerTokens.some(token => {
        const tokenStem = stemmer.stem(token);
        const distance = natural.LevenshteinDistance(tokenStem, keywordStem);
        return tokenStem.includes(keywordStem) || distance <= 2;
      });
    });

    const missingKeywords = requiredKeywords.filter(k => !matchedKeywords.includes(k));
    const keywordMatchRatio = matchedKeywords.length / requiredKeywords.length;

    // 📊 3. TF-IDF weighting for concept richness
    tfidf.addDocument(answer);
    let semanticScore = 0;
    requiredKeywords.forEach(k => {
      tfidf.tfidfs(k, (i, measure) => {
        semanticScore += measure;
      });
    });
    semanticScore = Math.min(semanticScore / requiredKeywords.length, 1.0);

    // 🎯 4. Role & experience-level weighting
    const roleWeight =
      role.toLowerCase().includes("frontend") ? 1.1 :
      role.toLowerCase().includes("backend") ? 1.15 :
      role.toLowerCase().includes("ml") ? 1.25 :
      1.0;

    const expWeight =
      experienceLevel.toLowerCase() === "intern" ? 0.8 :
      experienceLevel.toLowerCase() === "junior" ? 0.9 :
      experienceLevel.toLowerCase() === "mid" ? 1.0 :
      experienceLevel.toLowerCase() === "senior" ? 1.2 :
      1.0;

    const depthScore = Math.min((sentenceCount / 5) * expWeight, 1.2);
    const clarityScore = Math.min(uniqueWords / wordCount, 1.0);

    // ⚙️ 5. Final weighted composite score
    const matchPercentage = Math.min(
      100 *
      (0.45 * keywordMatchRatio +
       0.25 * semanticScore +
       0.15 * clarityScore +
       0.15 * depthScore) *
      roleWeight,
      100
    );

    // 🏷️ 6. Classification
    const classification =
      matchPercentage >= 85 ? "Outstanding" :
      matchPercentage >= 70 ? "Strong" :
      matchPercentage >= 55 ? "Moderate" :
      "Needs Improvement";

    // 💬 7. Feedback generation (context-aware)
    let feedback = `Analysis for a ${experienceLevel}-level ${role} at ${company}:\n\n`;
    feedback += `Your answer demonstrates a ${classification.toLowerCase()} understanding of the topic.\n`;
    feedback += `It covered approximately ${Math.round(matchPercentage)}% of the expected concepts.\n`;

    if (matchedKeywords.length) {
      feedback += `✅ Covered key terms: ${matchedKeywords.join(", ")}.\n`;
    }
    if (missingKeywords.length) {
      feedback += `⚠️ Missing important concepts: ${missingKeywords.join(", ")}.\n`;
    }

    if (depthScore < 0.6)
      feedback += `💡 Add more detailed explanations or examples to show depth of understanding.\n`;
    if (clarityScore < 0.3)
      feedback += `🧩 Try using more diverse vocabulary to make your explanation clearer.\n`;
    if (semanticScore < 0.4)
      feedback += `🧠 Include more technical or role-specific terms to strengthen the conceptual link.\n`;

    if (sentenceCount < 3)
      feedback += `📖 Expand your answer beyond a brief summary — structure it as problem, approach, and reasoning.\n`;
    else if (sentenceCount > 12)
      feedback += `✂️ Try condensing your response slightly to improve focus and coherence.\n`;

    return {
      classification,
      matchedKeywords,
      missingKeywords,
      matchPercentage,
      feedback,
      detailedAnalysis: {
        wordCount,
        uniqueWords,
        sentenceCount,
        averageWordLength,
        keywordDensity: (matchedKeywords.length / wordCount) * 100,
        semanticScore: Number(semanticScore.toFixed(2)),
        clarityScore: Number(clarityScore.toFixed(2)),
        depthScore: Number(depthScore.toFixed(2)),
      },
    };
  } catch (error) {
    console.error("Evaluation error:", error);
    throw new Error("Failed to evaluate answer");
  }
}


// -------------------- EXISTING ROUTES --------------------
app.get('/questions/:role', (req, res) => {
  try {
    const role = req.params.role;
    if (!role) return res.status(400).json({ error: "Role parameter is required" });

    const roleQuestions = questions[role];
    if (!roleQuestions) return res.status(404).json({ error: `No questions found for role: ${role}` });

    // Optional filtering by experience level. Client may pass ?experienceLevel=Junior
    const expLevel = req.query.experienceLevel;
    if (expLevel) {
      const allowed = allowedDifficultiesForLevel(expLevel);
      if (Array.isArray(allowed)) {
        const filtered = roleQuestions.filter((q) => {
          const diff = (q.difficulty || 'Medium').toString().toLowerCase();
          return allowed.includes(diff);
        });
        // If filtering removed all items, fall back to returning the original set
        return res.json(filtered.length ? filtered : roleQuestions);
      }
    }

    res.json(roleQuestions);
  } catch (error) {
    console.error('Error fetching questions:', error);
    res.status(500).json({ error: "Failed to fetch questions" });
  }
});

app.post("/evaluate", (req, res) => {
  try {
    const { answer, question, role, company, experienceLevel } = req.body;
    if (!answer || !question || !question.requiredKeywords)
      return res.status(400).json({ error: "Missing required data" });

    const result = evaluateAnswer(answer, question, { role, company, experienceLevel });
    res.json(result);
  } catch (error) {
    console.error("Evaluation error:", error);
    res.status(500).json({ error: "Failed to analyze answer", details: error.message });
  }
});


// -------------------- AI SUGGESTED ANSWER --------------------
app.post("/suggest-answer", async (req, res) => {
  try {
    const { question, requiredKeywords } = req.body;

    if (!question || !requiredKeywords) {
      return res.status(400).json({ error: "Missing question or keywords" });
    }

    const prompt = `
You are an interview assistant. 
Answer the following interview question briefly and directly — keep it under 100 words. 
Avoid bullet points, subheadings, or lengthy explanations. 
Focus only on clarity, accuracy, and the required key terms. 
Question: "${question}" 
Make sure to include these concepts naturally: ${requiredKeywords.join(", ")}. 
Keep the tone concise and professional, suitable for a verbal interview answer.`;

    const response = await axios.post(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
      {
        contents: [{ parts: [{ text: prompt }] }],
      },
      {
        headers: { "Content-Type": "application/json" },
        params: { key: process.env.HUGGINGFACE_API_KEY },
      }
    );

    const suggestedAnswer =
      response.data?.candidates?.[0]?.content?.parts?.[0]?.text ||
      "Could not generate an answer at this time.";

    const tokenizer = new natural.WordTokenizer();
    const tokens = tokenizer.tokenize(suggestedAnswer.toLowerCase());
    const missingKeywords = requiredKeywords.filter(
      (keyword) => !tokens.some((token) => token.includes(keyword.toLowerCase()))
    );

    let enhancedAnswer = suggestedAnswer;
    if (missingKeywords.length > 0) {
      enhancedAnswer +=
        "\n\nAdditional important concepts to consider:\n" +
        missingKeywords
          .map(
            (keyword) =>
              `- ${keyword}: This is a crucial aspect that should be mentioned in this context.`
          )
          .join("\n");
    }

    res.json({ suggestedAnswer: enhancedAnswer });
  } catch (error) {
    console.error("AI suggestion error:", error.response?.data || error.message);
    const fallbackAnswer =
      `Here's a suggested approach to answering this question:\n\n` +
      `1. Start by defining the core concepts:\n` +
      requiredKeywords
        .map(
          (keyword, index) =>
            `   ${index + 1}. ${keyword}: Explain how this concept relates to the question`
        )
        .join("\n") +
      `\n\n2. Connect these concepts together to form a comprehensive answer.\n` +
      `3. Provide practical examples where possible.\n` +
      `4. Conclude by summarizing the key points.`;
    res.json({ suggestedAnswer: fallbackAnswer });
  }
});

// -------------------- NEW ROUTE: GENERATE QUESTIONS --------------------
async function generateQuestions({ company, role, experienceLevel }) {
  const sanitizeJsonLike = (txt) => {
    if (!txt) return "";

    // Remove markdown fences
    let s = txt.replace(/```json|```/gi, "");

    // Replace smart quotes with standard ones
    s = s
      .replace(/\u201C|\u201D|\u201E|\u201F/g, '"')
      .replace(/\u2018|\u2019|\u2032/g, "'")
      .replace(/\u00A0/g, " "); // non-breaking space

    // Remove ellipses and extra punctuation
    s = s.replace(/\u2026|\.{3}/g, "");

    // Trim any leading text before first [ and trailing after last ]
    const start = s.indexOf("[");
    const end = s.lastIndexOf("]");
    if (start !== -1 && end !== -1 && end > start) {
      s = s.slice(start, end + 1);
    }

    // Remove trailing commas before } or ]
    s = s.replace(/,(\s*[}\]])/g, "$1");

    return s.trim();
  };

  const prompt = `
You are an AI that creates interview questions.
Generate EXACTLY 3 technical interview questions for a ${experienceLevel}-level ${role} at ${company}.
Respond ONLY with valid JSON (ASCII characters only), no markdown, no commentary.
Format:
[
  {"question": "...", "difficulty": "Easy|Medium|Hard", "requiredKeywords": ["kw1","kw2","kw3","kw4","kw5"]},
  {"question": "...", "difficulty": "Easy|Medium|Hard", "requiredKeywords": ["kw1","kw2","kw3","kw4","kw5"]},
  {"question": "...", "difficulty": "Easy|Medium|Hard", "requiredKeywords": ["kw1","kw2","kw3","kw4","kw5"]}
]
`.trim();

  const callGemini = async (text) => {
    const { data } = await axios.post(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
      {
        contents: [{ parts: [{ text }] }]
        
      },
      {
        headers: { "Content-Type": "application/json" },
        params: { key: process.env.HUGGINGFACE_API_KEY }
      }
    );
    return data?.candidates?.[0]?.content?.parts?.[0]?.text || "";
  };

  let aiText = await callGemini(prompt);

  console.log("\n---------------- RAW GEMINI OUTPUT ----------------");
  console.log(aiText || "(empty response)");
  console.log("---------------------------------------------------\n");

  // Retry if nothing came back
  if (!aiText.trim()) {
    console.log("⚠️ Empty response — retrying...");
    const retryPrompt = `
Return 3 interview questions for a ${experienceLevel}-level ${role} at ${company} in JSON format.
Each should include a question, difficulty, and 3-5 keywords.
`.trim();
    aiText = await callGemini(retryPrompt);
  }

  // 🧠 Step 1: Try parsing the original Gemini output directly
  try {
    const parsed = JSON.parse(aiText);
    if (Array.isArray(parsed) && parsed.length) return parsed;
  } catch (e) {
    console.warn("Direct parse failed:", e.message);
  }

  // 🧹 Step 2: Sanitize only if needed
  const cleaned = sanitizeJsonLike(aiText);

  try {
    const parsed = JSON.parse(cleaned);
    if (Array.isArray(parsed) && parsed.length) return parsed;
  } catch (e) {
    console.warn("Sanitized parse failed:", e.message);
  }

  // 🧩 Step 3: Fallback extraction
  const questionMatches = (aiText || "").match(/"(question)"\s*:\s*"([^"]+?)"/g);
  if (questionMatches) {
    return questionMatches.slice(0, 3).map((q) => ({
      question: q.replace(/.*"question"\s*:\s*"([^"]+)".*/, "$1"),
      difficulty: "Medium",
      requiredKeywords: []
    }));
  }

  // 🛑 Step 4: Last resort fallback
  return [
    {
      question: "Describe how you would design and scale a system for this role.",
      difficulty: "Medium",
      requiredKeywords: []
    }
  ];
}


app.post("/generate-question", async (req, res) => {
  try {
    const { company, role, experienceLevel } = req.body;

    if (!company || !role || !experienceLevel) {
      return res.status(400).json({
        error: "Missing parameters. Please provide company, role, and experienceLevel.",
      });
    }

    const questions = await generateQuestions({ company, role, experienceLevel });
    return res.json(questions);
  } catch (err) {
    console.error("Error generating questions:", err.response?.data || err.message);
    return res.status(500).json({ error: "Failed to generate questions dynamically" });
  }
});

// -------------------- SERVER --------------------
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`✅ Server running on port ${PORT}`));
